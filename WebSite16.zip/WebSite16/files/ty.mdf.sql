﻿CREATE TABLE [dbo].[Table]
(
	[rno] INT NOT NULL PRIMARY KEY, 
    [name] NCHAR(10) NULL, 
    [city] NCHAR(10) NULL
)
