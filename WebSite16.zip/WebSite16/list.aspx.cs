﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\ADMIN\Documents\Visual Studio 2012\WebSites\WebSite16\App_Data\assignment.mdf;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        //con.Open();
        //SqlCommand cmd = new SqlCommand("select *from assi", con);
        //SqlDataReader dr = cmd.ExecuteReader();
        //if (dr.HasRows)
        //{
        //    Response.Write("<table border=1>");
        //    while (dr.Read())
        //    {
        //        Response.Write("<tr><td>" + dr[0] + "</td>");
        //        Response.Write("<td>" + dr[1] + "</td>");
        //        Response.Write("<td>" + dr[2] + "</td>");
        //        Response.Write("<td>" + dr[3] + "</td></tr>");
        //    }
        //    Response.Write("</table>");
        //}
        //con.Close();
    }
   
}