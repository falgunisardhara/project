﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\ADMIN\Documents\Visual Studio 2012\WebSites\WebSite16\App_Data\assignment.mdf;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        con.Open();
        if (Session["user"] == null)
        {
            Response.Redirect("index.aspx");
        }
        //SqlCommand cmd = new SqlCommand("select *from assi", con);
        //SqlDataReader dr = cmd.ExecuteReader();
        ////GridView1.DataSource = dr;
        ////GridView1.DataBind();
        ////cmd.ExecuteNonQuery();
        //dr.Close();
        con.Close();
    }

    
}