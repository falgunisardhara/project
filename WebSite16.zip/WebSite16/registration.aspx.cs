﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\ADMIN\Documents\Visual Studio 2012\WebSites\WebSite16\App_Data\assignment.mdf;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        con.Open();
        SqlCommand cmd = new SqlCommand("select *from registration", con);
        SqlDataReader dr = cmd.ExecuteReader();
        dr.Close();
        con.Close();
    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {
        con.Open();
        string qry="insert into registration values('"+tbx_fnm.Text+"','"+tbx_lnm.Text+"','"+tbx_adrs.Text+"','"+ddl_ct.SelectedValue+"','"+tbx_mno.Text+"','"+tbx_email.Text+"','"+tbx_dob.Text+"')";
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Redirect("home.aspx");
    }
}