﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class admin_Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\ADMIN\Documents\Visual Studio 2012\WebSites\WebSite16\App_Data\assignment.mdf;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           
        }
        ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        con.Open();
        SqlCommand cm = new SqlCommand("select *from login", con);
        SqlDataReader dr = cm.ExecuteReader();
        con.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        string qry = "insert into login values('" + tbx_unm.Text + "','" + tbx_pwd.Text + "')";
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();
        con.Close();
        string unm, pwd;
        unm = tbx_unm.Text;
        pwd = tbx_pwd.Text;
        if (unm == "admin" && pwd == "admin")
        {
            Session["user"] = unm;
            Response.Redirect("login_list.aspx");
            //Response.Write("login success");
        }
        else
        {
            Response.Write("login fail");
        }
    }
}