﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;

public partial class admin_Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\ADMIN\Documents\Visual Studio 2012\WebSites\WebSite16\App_Data\assignment.mdf;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        //con.Open();
        //SqlCommand cm = new SqlCommand("select *from assi", con);
        //SqlDataReader dr = cm.ExecuteReader();
        //con.Close();
        //if (!IsPostBack)
        //{
        //    string[] filePaths = Directory.GetFiles(Server.MapPath("~/files/"));
        //    List<ListItem> files = new List<ListItem>();
        //    foreach (string filePath in filePaths)
        //    {
        //        files.Add(new ListItem(Path.GetFileName(filePath), filePath));
        //    }
        //    //GridView1.DataSource = files;
        //    //GridView1.DataBind();
        //}

    }
    protected void btn_upload_Click(object sender, EventArgs e)
    {
        con.Open();
        string q = "insert into assi values('" + tbx_sub_code.Text + "','" + ddl_sub_nm.SelectedValue + "','" + FileUpload1.FileName + "')";
        SqlCommand cmd = new SqlCommand(q,con);
        string fnm = MapPath("files/" + FileUpload1.FileName);
        cmd.ExecuteNonQuery();
        Label1.Text = "your files is uploaded";
        con.Close();
    }
    //protected void UploadFile(object sender, EventArgs e)
    //{
    //    string fileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
    //    FileUpload1.PostedFile.SaveAs(Server.MapPath("~/files/") + fileName);
    //    Response.Redirect(Request.Url.AbsoluteUri);
    //}
}
