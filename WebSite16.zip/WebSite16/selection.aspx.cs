﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_ok_Click(object sender, EventArgs e)
    {
        
        if (ddl_year.SelectedValue == "1st year")
        {
            Response.Redirect("sem1and2.aspx");
        }
        else if (ddl_year.SelectedValue == "2nd year")
        {
            Response.Redirect("sem3and4.aspx");
        }
        else if (ddl_year.SelectedValue == "3rd year")
        {
            Response.Redirect("sem5and6.aspx");
        }
        else
        {
            Response.Write("please select your year");
        }


    }
}