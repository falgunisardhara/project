-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 13, 2019 at 11:53 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_watch`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_to_cart`
--

CREATE TABLE `add_to_cart` (
  `id` int(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `pro_name` varchar(30) NOT NULL,
  `pro_image` text NOT NULL,
  `pro_price` int(30) NOT NULL,
  `quantity` int(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `id` int(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `mobile_no` bigint(10) NOT NULL,
  `pro_name` varchar(30) NOT NULL,
  `cat_name` varchar(300) NOT NULL,
  `quantity` int(5) NOT NULL,
  `pro_price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`id`, `username`, `mobile_no`, `pro_name`, `cat_name`, `quantity`, `pro_price`) VALUES
(2, 'vishva', 1234567890, 'omega watch', 'couple', 4, 11000);

-- --------------------------------------------------------

--
-- Table structure for table `category_data`
--

CREATE TABLE `category_data` (
  `id` int(10) NOT NULL,
  `cat_image` text NOT NULL,
  `cat_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `category_data`
--

INSERT INTO `category_data` (`id`, `cat_image`, `cat_name`) VALUES
(1, 'men.jpg', 'men'),
(2, 'women.jpg', 'women'),
(3, 'couple.jpg', 'couple'),
(4, 'kids.jpg', 'kids');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile_no` bigint(10) NOT NULL,
  `message` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `username`, `email`, `mobile_no`, `message`) VALUES
(1, 'falu', 'abc@gmail.com', 1234567890, '');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(10) NOT NULL,
  `pro_name` varchar(30) NOT NULL,
  `pro_company` varchar(20) NOT NULL,
  `pro_category` varchar(300) NOT NULL,
  `pro_image` text NOT NULL,
  `pro_price` int(50) NOT NULL,
  `stock` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `pro_name`, `pro_company`, `pro_category`, `pro_image`, `pro_price`, `stock`) VALUES
(13, 'watch1', 'omega', 'men', 'omega classic rose gold men watch.jpg', 4500, 123),
(14, 'watch1', 'omega', 'men', 'omega seamaster aqua terra men watch.jpg', 8000, 56),
(15, 'watch1', 'omega', 'men', 'omega seamaster automatic men watch.jpg', 6500, 88),
(16, 'watch1', 'omega', 'men', 'omega swiss luxury blue dial men watch.jpg', 8800, 34),
(17, 'watch1', 'omega', 'men', 'omega black dial men watch.jpg', 5800, 12),
(18, 'watch1', 'omega', 'men', 'omega seamaster chronograph men watch.jpg', 4500, 44),
(19, 'watch2', 'omega', 'women', 'omega gold & diamond women watch.jpg', 8000, 77),
(20, 'watch2', 'omega', 'women', 'omega seamaster rose gold women watch.jpg', 9000, 98),
(21, 'watch2', 'omega', 'women', 'omega seamaster aqua rose gold women watch.jpg', 5000, 123),
(22, 'watch2', 'omega', 'women', 'omega diamond women watch.jpg', 4500, 56),
(23, 'watch2', 'omega', 'women', 'omega seamaster aqua women watch.jpg', 6000, 67),
(24, 'watch2', 'omega', 'women', 'omega seamaster aqua blue dial women watch.jpg', 4000, 78),
(25, 'watch3', 'omega', 'couple', 'omega black dial autyomatic couple watch.jpg', 9000, 123),
(26, 'watch3', 'omega', 'couple', 'omega rose gold couple watch.jpg', 8000, 98),
(27, 'watch3', 'omega', 'couple', 'omega seamaster gold couple watch.jpg', 7000, 77),
(28, 'watch3', 'omega', 'couple', 'omega black dial silver couple watch.jpg', 6000, 67),
(29, 'watch3', 'omega', 'couple', 'omega seamaster silver couple watch.jpg', 4500, 77),
(30, 'watch3', 'omega', 'couple', 'omega gold dial couple watch.jpg', 5000, 123),
(31, 'watch4', 'omega', 'kids', 'omega purple kids watch.jpg', 999, 56),
(32, 'watch4', 'omega', 'kids', 'omega white dial kids watch.jpg', 888, 77),
(33, 'watch4', 'omega', 'kids', 'omega digital LED kids watch.jpg', 1000, 77),
(34, 'watch4', 'omega', 'kids', 'omega pink girlysh kids watch.jpg', 1200, 56),
(35, 'watch4', 'omega', 'kids', 'omega silver dial kids watch.jpg', 1500, 98),
(36, 'watch4', 'omega', 'kids', 'omega pink kitty kids watch.jpeg', 2000, 78),
(37, 'watch5', 'rolex', 'men', 'rolex daytona classic zenith men watch.jpg', 9000, 67),
(38, 'watch5', 'rolex', 'men', 'rolex rhodium diamond dial white gold men watch.jpg', 8000, 56),
(39, 'watch5', 'rolex', 'men', 'rolex lvory rose gold oyster men watch.jpg', 10000, 98),
(40, 'watch5', 'rolex', 'men', 'rolex gold men watch.jpg', 15000, 67),
(41, 'watch5', 'rolex', 'men', 'rolex datejust white gold bezel  men watch.jpg', 7000, 123),
(42, 'watch5', 'rolex', 'men', 'rolex gold & diamond dial men watch.jpg', 20000, 56),
(43, 'watch6', 'rolex', 'women', 'rolex platinum president silver women watch.jpg', 8000, 78),
(44, 'watch6', 'rolex', 'women', 'rolex black dial silver women watch.jpg', 10000, 98),
(45, 'watch6', 'rolex', 'women', 'rolex pearl diamond women watch.jpg', 15000, 78),
(46, 'watch6', 'rolex', 'women', 'rolex star diamond dial &rose gold women watch.jpg', 11000, 98),
(47, 'watch6', 'rolex', 'women', 'rolex blue dial with diamond women watch.jpg', 9000, 123),
(48, 'watch6', 'rolex', 'women', 'rolex white dial women watch.jpg', 8000, 56),
(49, 'watch7', 'rolex', 'couple', 'rolex diamond dial rose gold couple watch.jpg', 15000, 78),
(50, 'watch7', 'rolex', 'couple', 'rolex gold matching couple watch.jpg', 20000, 98),
(51, 'watch7', 'rolex', 'couple', 'rolex silver couple watch.jpg', 10000, 123),
(52, 'watch7', 'rolex', 'couple', 'rolex gold &rose gold couple watch.jpg', 12000, 77),
(53, 'watch7', 'rolex', 'couple', 'rolex submarin & michael couple watch.jpg', 13000, 98),
(54, 'watch7', 'rolex', 'couple', 'rolex couple watch.jpg', 9000, 56),
(55, 'watch8', 'rolex', 'kids', 'rolex snowmen style strip kids watch.jpg', 10000, 78),
(56, 'watch8', 'rolex', 'kids', 'rolex pink strip frozen kids watch.jpg', 9000, 56),
(57, 'watch8', 'rolex', 'kids', 'rolex frozen kids watch.jpg', 11000, 78),
(58, 'watch8', 'rolex', 'kids', 'rolex blue strip kids watch.jpeg', 10000, 123),
(59, 'watch8', 'rolex', 'kids', 'rolex white dial pink strip kids watch.jpeg', 7000, 77),
(60, 'watch8', 'rolex', 'kids', 'rolex dora dial kids watch.jpg', 11000, 67),
(61, 'watch9', 'timex', 'men', 'timex men metal field watch.jpg', 10000, 56),
(62, 'watch9', 'timex', 'men', 'timex expendition men watch.jpg', 10000, 98),
(63, 'watch9', 'timex', 'men', 'timex men watch.jpg', 9000, 78),
(64, 'watch9', 'timex', 'men', 'timex Blue field men  watch.jpg', 9000, 56),
(65, 'watch9', 'timex', 'men', 'timex Blue field men  watch.jpg', 11000, 56),
(66, 'watch9', 'timex', 'men', 'timex EClass men  watch.jpg', 12000, 98),
(67, 'watch19', 'timex', 'men', 'timex steel bracelet  men watch.jpg', 13000, 123),
(68, 'watch10', 'timex', 'women', 'timex silver dial women watch.jpg', 8000, 77),
(69, 'watch10', 'timex', 'women', 'timex flower dial women watch.jpg', 9000, 67),
(70, 'watch10', 'timex', 'women', 'timex butterfly dial women watch.jpg', 11000, 78),
(71, 'watch10', 'timex', 'women', 'timex pink dial women watch.jpg', 12000, 77),
(73, 'watch10', 'timex', 'women', 'timex analog gold dial women  watch.jpg', 13000, 98),
(74, 'watch10', 'timex', 'women', 'timex lite pink women watch.jpg', 14000, 67),
(75, 'watch11', 'timex', 'couple', 'timex rose gold analog couple watch.jpg', 10000, 123),
(76, 'watch11', 'timex', 'couple', 'Timex Golden Couple watch.jpg', 11000, 78),
(77, 'watch11', 'timex', 'couple', 'timex empera silver dial couple watch.jpg', 13000, 77),
(78, 'watch11', 'timex', 'couple', 'timex golden rectangle couple watch.jpg', 14000, 56),
(79, 'watch11', 'timex', 'couple', 'timex classics silver-gold couple watch.jpg', 15000, 67),
(80, 'watch11', 'timex', 'couple', 'timex blue field couple watch.jpg', 16000, 98),
(81, 'watch12', 'timex', 'kids', 'timex fabric doodle kids watch.jpg', 8000, 123),
(82, 'watch12', 'timex', 'kids', 'timex white dial floral kids watch.jpg', 10000, 78),
(83, 'watch12', 'timex', 'kids', 'timex equa blue kids watch.jpg', 9000, 77),
(84, 'watch12', 'timex', 'kids', 'timex floral kids watch.jpg', 8000, 67),
(85, 'watch12', 'timex', 'kids', 'timex purple floral kids watch.jpg', 6000, 56),
(86, 'watch12', 'timex', 'kids', 'timex digital kids watch.jpg', 11000, 98),
(87, 'watch13', 'titan', 'men', 'titan blue dial men silver watch.jpg', 10000, 123),
(88, 'watch13', 'titan', 'men', 'titan black dial lather multi function men watch.jpg', 11000, 78),
(89, 'watch13', 'titan', 'men', 'titan octane men gold watch.jpg', 10000, 77),
(90, 'watch13', 'titan', 'men', 'titan black dial men gold & silver watch.jpg', 11000, 56),
(91, 'watch13', 'titan', 'men', 'titan black dial men silver watch.jpg', 9000, 67),
(92, 'watch13', 'titan', 'men', 'titan analog blue dial men silver watch.jpg', 12000, 98),
(93, 'watch14', 'titan', 'women', 'titan rose gold women watch.jpg', 10000, 123),
(94, 'watch14', 'titan', 'women', 'titan black dial women watch.png', 9000, 78),
(95, 'watch14', 'titan', 'women', 'titan rose gold dial women watch.png', 12000, 77),
(96, 'watch14', 'titan', 'women', 'titan diamond dial rose gole women watch.jpg', 14000, 67),
(97, 'watch14', 'titan', 'women', 'titan white dial gold women watch.jpg', 11000, 56),
(98, 'watch14', 'titan', 'women', 'titan silver dial silver women watch.jpg', 12000, 98),
(99, 'watch15', 'titan', 'couple', 'titan white dial silver couple watch.jpg', 11000, 123),
(100, 'watch15', 'titan', 'couple', 'titan blue dial silver couple watch.jpg', 12000, 78),
(101, 'watch15', 'titan', 'couple', 'titan white dial rose gold couple watch.jpg', 13000, 67),
(102, 'watch15', 'titan', 'couple', 'titan Bandhaan silver & gold couple watch.jpg', 9000, 77),
(103, 'watch15', 'titan', 'couple', 'titan white dial gold couple watch.jpg', 15000, 56),
(104, 'watch15', 'titan', 'couple', 'titan Bandhan white dial couple watch.jpg', 11000, 98),
(105, 'watch16', 'titan', 'kids', 'titan blue flower dial kids watch.jpg', 9000, 123),
(106, 'watch16', 'titan', 'kids', 'titan pink flower kids watch.jpeg', 7000, 78),
(107, 'watch16', 'titan', 'kids', 'titan green strip kids watch.png', 8000, 77),
(108, 'watch16', 'titan', 'kids', 'titan blue & white dial kids watch.png', 7000, 56),
(109, 'watch16', 'titan', 'kids', 'titan doremon orange kids watch.png', 8000, 67),
(110, 'watch16', 'titan', 'kids', 'titan pink hat kids watch.jpg', 8000, 98);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(8) NOT NULL,
  `confirm_password` varchar(8) NOT NULL,
  `mobile_no` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `username`, `first_name`, `last_name`, `email`, `password`, `confirm_password`, `mobile_no`) VALUES
(9, 'divya', '', '', 'hay@gmail.', '1234', '1234', 1234567890),
(10, 'vishva', '', '', 'abc@gmail.', '123', '123', 1234567890),
(11, 'lisa12', 'lisa', 'mehra', 'lisame@gma', '099', '123', 9087665432),
(12, 'lisa12', 'lisa', 'mehra', 'lisame@gma', '900', '099', 9087665432),
(13, 'divya', '', '', 'abc@gmail.com', '12345678', '12345678', 9876543210),
(14, 'divya', '', '', 'abc@gmail.com', '12345678', '12345678', 1234567890),
(15, 'divya', '', '', 'abc@gmail.com', '12345678', '12345678', 1234567890);

-- --------------------------------------------------------

--
-- Table structure for table `watch_order`
--

CREATE TABLE `watch_order` (
  `id` int(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `pro_name` varchar(30) NOT NULL,
  `pro_image` text NOT NULL,
  `pro_price` int(50) NOT NULL,
  `quantity` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `watch_order`
--

INSERT INTO `watch_order` (`id`, `username`, `pro_name`, `pro_image`, `pro_price`, `quantity`) VALUES
(1, 'divya', 'omega watch', 'timex analog gold dial women  watch.jpg', 4500, 4),
(2, 'divya', 'omega watch', 'omega seamaster aqua women watch.jpg', 999, 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_to_cart`
--
ALTER TABLE `add_to_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_data`
--
ALTER TABLE `category_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `watch_order`
--
ALTER TABLE `watch_order`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_to_cart`
--
ALTER TABLE `add_to_cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `category_data`
--
ALTER TABLE `category_data`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;
--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `watch_order`
--
ALTER TABLE `watch_order`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
