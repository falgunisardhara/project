<!DOCTYPE html>
<!--
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>TIC TOC! wrist watch</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		

		<!-- Header -->
			<header id="header">
				<h1><a href="index.php"></a></h1>
				<nav id="nav">
					<ul>
						<li><a href="home.php">HOME</a></li>
						<li><a href="about.php">ABOUT US</a></li>
						<li><a href="login.php">LOGIN</a></li>
						<li><a href="product.php">PRODUCT</a></li>
						<li><a href="log out.php">LOG OUT</a></li>
					</ul>
				</nav>
			</header>

		<!-- Banner -->
			<section id="banner" style="background-image:url(admin/images/home_se300m-21092442001001-large.jpg);">
				<h2>TIC TOC!</h2>
				<p>times of sweet moment!!!!!!!!!</p>
				<ul class="actions">
				</ul>
			</section>
