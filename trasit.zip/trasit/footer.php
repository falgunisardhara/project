<!DOCTYPE html>
<!--
	Transit by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Transit by TEMPLATED</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
	</head>
	<body class="landing">
	<!-- Footer -->
			<footer id="footer">
				<div class="container">
					<section class="links">
						<div class="row">
				</div>
					</section>
					<div class="row">
						<div class="8u 12u$(medium)">
							<ul class="copyright">
								<li>Developed by:</li><br>
								<li>Sardhara Falguni</li><br>
								<li>Parmar Divya</li><br>
								<li>Lunagariya Vishva</li><br>
							</ul>
						</div>
					<div class="4u$ 12u$(medium)">
							<ul class="icons">
								<li>
									<a><span><u><center>contact us:</center></u></span></a><br>
									<a><span>Email: tictocfdv@gmail.com</span></a><br>
									<a><span>contact no: +91 9876543219</span></a>
								</li>
							</ul>
						</div>
					</div>
			</footer>
