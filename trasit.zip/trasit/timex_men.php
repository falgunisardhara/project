<?php

	include("connection.php");
	include("header.php");
	$list_query="select *from product where pro_name='watch9'";
	$data_query=mysqli_query($db,$list_query);
	$path="images/";
while($list_data=mysqli_fetch_array($data_query)){?>

<html>
<table bgcolor="#FFFFFF">
	<tr>
		<td><img src="<?php echo "images/".$list_data['4'];?>" heigth="200" width="200"/>
		<?php echo  "RS- ".$list_data['5'];?></td><td><?php echo "stock " .$list_data['6'];?>
		<a href="cart_list.php"><input type="submit" name="cart" value="ADD TO CART"></a></td>
	</tr>
	
	
	<?php } ?>
	</table>
	</html>
	
<?php
	include("footer.php");
?>