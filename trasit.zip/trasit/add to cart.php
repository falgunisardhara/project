<?php

    include("connection.php");
	iquery="select pro_name from product";
     $id=$_GET['id'];
    $pronm=$_GET['name'];
	$pr=$_GET['price'];
	$i=$_GET['path'];
	$quantity=$_GET['quantity'];
	
	
	 $q="insert into add_to_cart(id,pro_name,pro_image,pro_price,quantity) values(NULL,'$pronm','$i','$pr','$quantity')";
	$c=mysqli_query($db,$q,$iquery) or die("can't insert");	
?>

<?php include("cart_list.php");?>