<?php

include("connection.php");
include("header.php");
$list_query="select *from category_data where cat_name='men'";
$data_query=mysqli_query($db,$list_query);
$path="images/";
while($list_data=mysqli_fetch_array($data_query)){?>

<html>
<body>
<head>
		<td><a href="omega_men.php"><img src="<?php echo "images/".$list_data['1'];?>" heigth="150" width="150"/></a></td><br>
		
		<!--<td><a href="omega_women.php"><img src="images/women.jpg" height="200"></a></td>
		<td><a href="omega_couple.php"><img src="images/couple.jpg" height="200"></a></td>
		<td><a href="omega_kids.php"><img src="images/kid's.jpg" height="200"></a></td>-->
<?php } ?>
</head>
</body>
</html>
<br></br>

<?php
$list_query="select *from category_data where cat_name='women'";
$data_query=mysqli_query($db,$list_query);
$path="images/";
while($list_data=mysqli_fetch_array($data_query)){?>

<html>
<body>
<head>
		<td><a href="omega_women.php"><img src="<?php echo "images/".$list_data['1'];?>" heigth="150" width="150"/></a></td><br>
		</td>
		
		<!--<td><a href="omega_women.php"><img src="images/women.jpg" height="200"></a></td>
		<td><a href="omega_couple.php"><img src="images/couple.jpg" height="200"></a></td>
		<td><a href="omega_kids.php"><img src="images/kid's.jpg" height="200"></a></td>-->
<?php } ?>
</head>
</body>
</html>

<?php
$list_query="select *from category_data where cat_name='couple'";
$data_query=mysqli_query($db,$list_query);
$path="images/";
while($list_data=mysqli_fetch_array($data_query)){?>

<html>
<body>
<head>	
		<td><a href="omega_couple.php"><img src="<?php echo "images/".$list_data['1'];?>" heigth="150" width="150"/></a></td><br>
		</td>
		
		<!--<td><a href="omega_women.php"><img src="images/women.jpg" height="200"></a></td>
		<td><a href="omega_couple.php"><img src="images/couple.jpg" height="200"></a></td>
		<td><a href="omega_kids.php"><img src="images/kid's.jpg" height="200"></a></td>-->
<?php } ?>
</head>
</body>
</html>

<?php
$list_query="select *from category_data where cat_name='kids'";
$data_query=mysqli_query($db,$list_query);
$path="images/";
while($list_data=mysqli_fetch_array($data_query)){?>

<html>
<body>
<head>	
		<td><a href="omega_kids.php"><img src="<?php echo "images/".$list_data['1'];?>" heigth="150" width="150"/></a></td><br>
		</td>
		
		<!--<td><a href="omega_women.php"><img src="images/women.jpg" height="200"></a></td>
		<td><a href="omega_couple.php"><img src="images/couple.jpg" height="200"></a></td>
		
		<td><a href="omega_kids.php"><img src="images/kid's.jpg" height="200"></a></td>-->

<?php } ?>
</head>
</body>
</html>


<?php

include("footer.php");

?>