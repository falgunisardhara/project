
<?php
 session_start();
 include "header.php";
 include "connection.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Billing Information..</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="main">
<?php
	$unm = $_REQUEST['unm'];
	$mno = $_REQUEST['mno'];
	$email = $_REQUEST['email'];
?>
         <h1 align="center">BILLING DETAILS</h1><br>
		 <form action="index.php" method="post">
         <table align="center" border="2">
      
          <tr>
		  <td colspan="3"><h2 align="center"><u>Order Detail..</u></h2></td>
		  </tr>
		  <tr>
		  <td>
		  Name: <?php echo $unm; ?><br />
          Contact : <?php echo $contact; ?><br />
          E-mail : <?php echo $email; ?></td>
          <td colspan="2">
		  </tr> 
		  <tr>
		  <th>Product Name</th>
		  <th>Qty</th>
		  <th colspan="1">Price</th>
		  </tr>
<?php
	$tot =0;
	$gtot=0;
	$billno;
	$selcart = "select * from add_to_cart where unm = '".$_SESSION['unm']."'";
    $bill_no=mysqli_query($iquery);
	$no=mysqli_fetch_row($bill_no);
	$no=$no[0]+1;
    $cartview = mysql_query($selcart);
		while($result=mysqli_fetch_row($cartview))
		{ 
				echo "<tr align='center'>
				<td>".$result[2]."</td>
				<td>".$result[4]."</td>
				<td>".$result[3]."</td>
				</tr>";
				$tot = $result[3];	
				$gtot= $gtot + $result[4] * $result[3];
				$order="INSERT INTO bill(bill_no,fname,lname,c_add,c_city,c_phone,c_mail,g_total) VALUES ('".$no."','".$fname."','".$lname."','".$add1."','".$city."','".$contact."','".$email."','".$tot."')";
		$confirm=mysqli_query($order);
		}
 	    echo "<tr align='center'><td colspan=2 align='right'>GRAND TOTAL:-&nbsp; </td>   <td>$gtot</td></tr>";
?>
		  <tr>	
	      <td class="submit" rowspan="5" colspan="3"><input type="submit" value="Done"></td>
		  </tr>
          </table>
		  </form>
		  </div>
</body>
</html>
<?php
 include "footer.php";
?>