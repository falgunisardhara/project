
	  <?php
	  include_once("header.php");
	  ?>
      <div class="clr"></div>
    </div>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><span><center><u>About us</u></center></span></h2></br>
          <div class="clr"></div>
         <h2> <p><strong>TIC TOC!  times of sweet moment!!!!!!!!</strong></p></h2>
         <h4> <p> All human being is like a wrist watch.Today,most inexpensive and medium priced watches are avaliable.We are glad to provide best quality accommodation and services which are surely satisfactionary for our customers.</p></h4>
        </div>
        <div class="article">
          <h2><span>Our</span> Mission</h2></br>
          <div class="clr"></div>
          <h4><p>Our mission is to provide best facilities to customers without any extra charges.</p></h4>
         <h4> <p>Despite so many digital gadgets telling us time,wrist watches have never gone out of fashion.somehow this small and delicate time machine has managed to keep its special place in our life.</p></h4>
         <h4><p>our mission is helps customers to find deffrent type of watches product.our website is important for those persons who confused for choosing one of companies product.</p></h4>
        
      </div>
	   <div class="article">
	  <h2><span>Services</span> Overview</h2></br>
	  <div class="clr"></div>
      <h4> <p>Established in the year 2019 we at <strong>"TIC TOC!"</strong> are one of the reowned wrist watch service providers.We are selling Men,Women,Kids and Couple watches of smart companies.Our website TIC TOC! is important for those person who confused for choosing one of the companies product.We provide facilities like services, discount, gauranty, delivery etc.</p></h4>
        </div>
		</div>
		
		                      <img src="images/rolex datejust white gold bezel  men watch.jpg" height="250" />
		                     <img src="images/omega diamond women watch.jpg" height="250"/>
		                     <img src="images/timex blue field couple watch.jpg" height="250"/>
							 <img src="images/titan pink hat kids watch.jpg" height="250"/>
							 	 
      <div class="clr"></div>
    </div>
  </div>
 
  <div class="footer">
  <?php
	  include_once("footer.php");
	  ?>
      
  </div>
</div>
</body>
</html>
