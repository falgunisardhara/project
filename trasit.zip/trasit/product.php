<!DOCTYPE html>
<?php
	include("connection.php");
	include("header.php");	
?>
<html>
<head></head>
<title>Product selection</title>
<body>
<table>
<h2 align="center">SELECT YOUR FAVIROUTE PRODUCT</h2>
<tr>
<td>
<a href="omega.php" ><img src="images/omega.png" height:"250" width="250"/></a><a href="omega_men.php"></a>
<a href="titan.php"><img src="images/titan.png" height:"200" width="250"/></a>
<a href="rolex.php"><img src="images/Rolex.png" height:"250" width="200"/></a>
<a href="timex.php"><img src="images/timex.png" height:"250" width="250"/></a>
</td>
</tr>
</table>
</body>
</html>

<?php include("footer.php");?>



<!--<html>
<div class="sidebar">
          <h2 class="star"><span>OUR PRODUCTS</span></h2>
          <div class="clr"></div>
          <ul class="sb_menu">
            <li><a href="#">OMEGA</a></li>
            <li><a href="#">ROLEX</a></li>
            <li><a href="#">TITAN</a></li>
            <li><a href="#">TIMEX</a></li>
          </ul>
        </div>

</html>-->
