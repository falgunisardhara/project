<!DOCTYPE html>
<html lang="en">
<head>
<title>TIC TOC!</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/grid.css" type="text/css" media="screen">
<script src="js/jquery-1.6.2.min.js"></script>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<link rel="stylesheet" href="css/ie.css" type="text/css" media="screen">
<![endif]-->
</head>
<body>
<?php include("header.php");
include("connection.php");
	global $total;
	
	$p="select *from add_to_cart";
	$res=mysqli_query($db,$p) or die("can't select");
?>  
<html>
<body>
<section id="content">
  <div class="bg-top">
    <div class="bg-top-2">
      <div class="bg">
        <div class="bg-top-shadow">
          <div class="main">
            <div class="box">
              <div class="padding">
                <div class="container_12">
                  <div class="wrapper">
                    <div class="grid_12">
                      <div class="indent-left">
                        <h3 class="p2">Add to cart</h3>
	
	
        	<table width="680px" cellspacing="0" cellpadding="5">
                   	  	<tr bgcolor="#ddd">
                        	<th width="220" align="left">pro_name </th> 
                        	<th width="180" align="left">pro_image</th> 
                       	  	<th width="100" align="center">Quantity </th> 
                        	<th width="30" align="right">Price </th> 
                        	
                        	
                      	</tr>
                    	<tr>
						

				<?php		
	while($rows=mysqli_fetch_array($res))
	{	
        echo "<form name='f1' action='shoppingf.php' method='get'>";
		echo "<td><img src='images/$rows[2]' height=100 widht=100></td>";?>
	
		<?php
        echo "<td>$rows[1]</td>";
		echo "<td align='center'><input type='text' name='t1[]' value='1' style='width: 20px; text-align: right'/></td>";
		echo "<td align='right'>$rows[3]</td> ";
        echo "<td><a href=product.php?path=".$rows[1].">Remove</a></td>";
		$total=$total+$rows[3];
				echo "</tr>";
				}?>
						   <tr>
                       
                           &nbsp;&nbsp;&nbsp;&nbsp; <td align="right" style=" font-weight:30"> Total </td>
                            <?php echo "<td align='right' >$total </td>"?>
                            <td align="right" style=" font-weight:bold"></td>
                            <td align="right" style="font-weight:bold"> </td>
						</tr>
					</table>
					
                    <center>
                   <a href="order.php" ><input type="submit" value="order" class="button"/></a>
					<!--<p><a href="shopping.php">Proceed to checkout</a></p>-->
                    <p><a href="product.php">Continue shopping</a></p></center>
                    	<?php echo"</form>";?>
                             </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
	</section>
	</body>
	  </html>  
      
    <?php include("footer.php");?>
     