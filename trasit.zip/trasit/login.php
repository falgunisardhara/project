<?php
session_start();
include ("connection.php");
include("header.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>TIC TOC!</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="main">
			<!--<form name="login" method="post" action="login.php" onsubmit="return validate(this)">-->
			<form action="product.php" method="post">
			 <?php
			  if(isset($_GET['msg'])) 
			  echo $_GET['msg'];
			   ?>
			<h2 align="center">LogIn</h2>
			<br />
		
							<table align="center">
	
					<tr><td>User Name</td><td><input type="text" name="unm"required/></td></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr><td>Password</td><td><input type="password" name="pwd" minilength="8"required /></td></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr><td>
					  <input type="submit" name="login_submit" value="Login" />
				</td>
					<td>  <input type="reset" name="login_reset" value="Reset" /></td>
				</tr>
				<tr></tr>
				<tr></tr>
				<tr></tr>
					<tr><td><a href="registration.php">Registration</a></td></tr>
				</table>
			</form>
		</div>
</body>
</html>

<!--script to validate the login form on submit -->
<!--<script type="text/javascript">
function validate(login)
{
	if(login.unm.value == "")
	{
		alert("User Name Can Not Blank");
		login.unm.focus();
		return false;
	}
	if(login.pwd.value == "")
	{
		alert("Password Can Not Blank");
		login.pwd.focus();
		return false;
	}
}	
function onlyChar(e)
{
	var charCode=e.which || e.keyCode;
	if((charCode >= 65 && charCode <=90)|| (charCode >= 97 && charCode <=122) || charCode==9 || charCode==46 || charCode==8)
	return true;
	
	return false;
}
</script>-->
<?php
if(isset($_POST['unm']))
{
	 $unm = $_POST['unm'];
 	 $pwd =  md5($_POST['pwd']);//Password Encoding 
	 $rs = mysqli_query("select * from registration where username='".$_POST["unm"]."' and password='".$_POST["pwd"]."'");
	 $cnt=mysqli_num_rows($rs);
	 if($cnt >= 1)
	 {
	
		$_SESSION['unm'] = $unm;	
	 	header("Location:product.php");
	 }
	else	
	{
		$msg = "<center><h4>Username or Password are not correct, try again.</center></h4>";
		header("Location:login.php?msg=$msg");
	}
}	 
 ?>
 
<?php
include("footer.php");
?>