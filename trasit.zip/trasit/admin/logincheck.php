<?php
session_start();

include("connection.php");
$unm=$_POST['unm'];
$pwd=$_POST['pwd'];
$rs = mysqli_num_rows(mysqli_query("select *from registration where unm='".$unm."' and pwd='".$pwd."'"));
if($rs >= 1)
{
	$_SESSION ['unm'] = $unm;

	header("location:index.php");

}else
{
	$msg = "user name and pass not correct.";
	header("location:login.php?msg=$msg");
	

	}

?>