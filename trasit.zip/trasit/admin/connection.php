<?php
	$db=mysqli_connect("localhost","root","","online_watch");
	
	if(!$db){
		die("connection faield".mysqli_connect_error());
	}//echo "connection successfully";
?>