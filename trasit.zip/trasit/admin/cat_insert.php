<?php
include("header.php");
?>
<html>
<body>
<h2 align="center">CATEGORY</h2>

<form method="post" enctype="multipart/form-data">
<table>

<tr>
<td align="center">CATEGORY IMAGE</td>
<td><input type="file" name="img"/>
</td>
</tr>

<tr>
<td align="center">CATEGORY NAME</td>
<td><input type="text" name="catnm" />
</td>
</tr>

<tr>
<td align="right"><input type="submit" name="submit" /><input type="reset" name="clear"/>
</td>
</tr>
</table>
</form>
</body>
</html>

<?php
	include("connection.php");
	if(isset($_REQUEST['submit']))
	{
		$img=$_FILES['img']['name'];
		$target_dir="images/";
		$imgs=$target_dir.basename($img);
		move_uploaded_file($_FILES['img']['tmp_name'],$imgs);
		$catnm=$_POST['catnm'];
	
	    $iquery="insert into category_data(id,cat_image,cat_name)
		values(NULL,'".$img."','".$catnm."')";
		
		$p1=mysqli_query($db,$iquery);
		
		if($p1=1)
		{
			header("location:cat_list.php?msg1=inserted");
		}
		if($p1=0)
		{
			echo"not inserted";
		}
	}
	include("footer.php");
?>


