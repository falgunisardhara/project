<!DOCTYPE html>
<!--
	Transit by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Transit by TEMPLATED</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
		

		<!-- Header -->
			<header id="header">
				<h1><a href="index.html"></a></h1>
				<nav id="nav">
					<ul>
						<li><a href="home.php">HOME</a></li>
						<li><a href="about_us.html">about us</a></li>
						<li><a href="pro_insert.php">products</a></li>
						<li><a href="log out.php">log out</a></li>
					</ul>
				</nav>
			</header>

		<!-- Banner -->
			<section id="banner" style="background-image:url(../images/home_se300m-21092442001001-large.jpg);">
				<h2>TIC TOC!
				</h2>
				<p>times of sweet moment!!!!!!!!!</p>
				<ul class="actions">
				</ul>
			</section>
