<?php
include("header.php");
?>
<html>
<body>
<h2 align="center">WATCH ORDER</h2>

<form method="post" enctype="multipart/form-data">
<table>
<tr>
<td align="center">USER NAME</td>
<td><input type="text" name="unm" />
</td>

</tr>
<tr>
<td align="center">PRODUCT NAME</td>
<td><input type="text" name="pronm" />
</td>
</tr>

<tr>
<td align="center">PRODUCT IMAGE</td>
<td><input type="file" name="img"/>
</td>
</tr>

<tr>
<td align="center">PRODUCT PRICE</td>
<td><input type="text" name="price" />
</td>
</tr>

<tr>
<td align="center">QUANTITY</td>
<td><input type="text" name="qty" />
</td>
</tr>

<tr>
<td align="right"><input type="submit" name="submit" /><input type="reset" name="clear"/>
</td>
</tr>
</table>
</form>
</body>
</html>

<?php
	include("connection.php");
	if(isset($_REQUEST['submit']))
	{
		$unm=$_POST['unm'];
		$pronm=$_POST['pronm'];
		
		$img=$_FILES['img']['name'];
		$target_dir="images/";
		$imgs=$target_dir.basename($img);
		move_uploaded_file($_FILES['img']['tmp_name'],$imgs);
		$price=$_POST['price'];
		$qty=$_POST['qty'];
		
	    $iquery="insert into watch_order(id,username,pro_name,pro_image,pro_price,quantity)values(NULL,'".$unm."','".$pronm."','".$img."','".$price."','".$qty."')";
		$p1=mysqli_query($db,$iquery);
		
		if($p1=1)
		{
			header("location:order_list.php?msg1=inserted");
		}
		if($p1=0)
		{
			echo"not inserted";
		}
	}
	include("footer.php");
?>


