<?php
include("header.php");
include("connection.php");
$uid=$_GET['update_id'];
$uquery="select *from registration where id=".$uid;
$up_query=mysqli_query($db,$uquery);
$updata=mysqli_fetch_array($up_query);
?>

<html>
<body>

<h2 align="center">UPDATE REGISTRATION FORM</h2>
<form method="post" enctype="multipart/formdata">
<table>

<tr>
<td align="center">Username</td>
<td><input type="text" name="unm" value="<?php echo $updata['username'];?>"/>
</td>
</tr>

<tr>
<td align="center">Email</td>
<td><input type="text" name="email" value="<?php echo $updata['email'];?>"/>
</td>
</tr>

<tr>
<td align="center">Password</td>
<td><input type="password" name="pwd" value="<?php echo $updata['password'];?>"/>
</td>
</tr>

<tr>
<td align="center">Confirm password</td>
<td><input type="password" name="conpwd" value="<?php echo $updata['confirm_password'];?>"/>
</td>
</tr>

<tr>
<td align="center">Mobile no</td>
<td><input type="text" name="mno" value="<?php echo $updata['mobile_no'];?>"/>
</td>
</tr>

<tr>
<td align="center"><input type="submit" name="update" value="Update"/><br>
</td>
</tr>

</table>
</body>
</html>

<?php
if(isset($_REQUEST['update']))
	{
		$unm=$_POST['unm'];
		$fnm=$_POST['fnm'];
		$lnm=$_POST['lnm'];
		$email=$_POST['email'];
		$pwd=$_POST['pwd'];
		$conpwd=$_POST['conpwd'];
		$mno=$_POST['mno'];
		
		$update_query="update registration set 
		username='".$unm."',
		first_name='".$fnm."',
		last_name='".$lnm."',
		email='".$email."',
		password='".$pwd."',
		confirm_password='".$conpwd."',
		mobile_no='".$mno."'
		where id='".$uid."'";
		
		$updatedata=mysqli_query($db,$update_query);
		if($updatedata=1){
			header("location:rlist.php");
		}
	}
	include("footer.php");
?>





















