<?php
	include("header.php");
	include("connection.php");
	$list_query="select *from watch_order";
	$data_query=mysqli_query($db,$list_query);
?>

<html>
<body>
<h2 align="center">WATCH ORDER DETAILS</h2>
<table border="2">
	<tr>
		<th>id</th>
		<th>unm</th>
		<th>pronm</th>
		<th>img</th>
		<th>price</th>
		<th>quantity</th>
		<th>action</th>
	</tr>
<?php
$path="images/";
while($list_data=mysqli_fetch_array($data_query)){?>
	
	<tr>
		<td><?php echo $list_data['0'];?></td>
		<td><?php echo $list_data['1'];?></td>
		<td><?php echo $list_data['2'];?></td>
		<td><img src="<?php echo $path.$list_data['3'];?>" heigth="100" width="100"/></td>
		<td><?php echo $list_data['4'];?></td>
		<td><?php echo $list_data['5'];?></td>
		
		<td><a href="order_delete.php?delete_id=<?php echo $list_data['id'];?>">DELETE</a></td>
		<td><a href="order_update.php?update_id=<?php echo $list_data['id'];?>">UPDATE</a></td>
		
	</tr>
<?php } ?>
</table>
</body>
</html>
<?php
include("footer.php");?>