<?php
	include("header.php");
	include("connection.php");
	$list_query="select *from registration";
	$data_query=mysqli_query($db,$list_query);
?>

<html>
<body>
<h2 align="center">REGISTRATION DETAILS</h2>
<table border="2">
	<tr>
		<th>id</th>
		<th>username</th>
		<th>email</th>
		<th>password</th>
		<th>confirm_password</th>
		<th>mobile_no</th>
		<th>action</th>
	</tr>
<?php
while($list_data=mysqli_fetch_array($data_query)){?>
	
	<tr>
		<td><?php echo $list_data['0'];?></td>
		<td><?php echo $list_data['1'];?></td>
		<td><?php echo $list_data['2'];?></td>
		<td><?php echo $list_data['3'];?></td>
		<td><?php echo $list_data['4'];?></td>
		<td><?php echo $list_data['5'];?></td>
		
		<td><a href="rdelete.php?delete_id=<?php echo $list_data['id'];?>">DELETE</a></td>
		<td><a href="rupdate.php?update_id=<?php echo $list_data['id'];?>">UPDATE</a></td>
		
	</tr>
<?php } ?>
</table>
</body>
</html>
<?php
	include("footer.php");
?>