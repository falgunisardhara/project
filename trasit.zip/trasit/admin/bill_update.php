<?php
include("header.php");
include("connection.php");
$uid=$_GET['update_id'];
$uquery="select *from bill where id=".$uid;
$up_query=mysqli_query($db,$uquery);
$updata=mysqli_fetch_array($up_query);
?>

<html>
<body>

<h2 align="center">BILL DETAILS</h2>

<form method="post" enctype="multipart/form-data">
<table>
<tr>
<td align="center">USER NAME</td>
<td><input type="text" name="unm" value="<?php echo $updata['username'];?>"/>
</td>
</tr>

</tr>
<tr>
<td align="center">MOBILE NO</td>
<td><input type="text" name="mno" value="<?php echo $updata['mobile_no'];?>" />
</td>
</tr>

<tr>
<td align="center">PRODUCT NAME</td>
<td><input type="text" name="pronm" value="<?php echo $updata['pro_name'];?>"/>
</td>
</tr>

<tr>
<td align="center">CATEGORY NAME</td>
<td><input type="text" name="catnm" value="<?php echo $updata['cat_name'];?>"/>
</td>
</tr>

<tr>
<td align="center">QUANTITY</td>
<td><input type="text" name="qty" value="<?php echo $updata['quantity'];?>" />
</td>
</tr>

<tr>
<td align="center">PRICE</td>
<td><input type="text" name="price" value="<?php echo $updata['pro_price'];?>"/>
</td>
</tr>

<tr>
<td align="right"><input type="submit" name="update" value="Update"/>
</td>
</tr>

</table>
</body>
</html>

<?php
if(isset($_REQUEST['update']))
	{
		$unm=$_POST['unm'];
		$mno=$_POST['mno'];
		$pronm=$_POST['pronm'];
		$catnm=$_POST['catnm'];
		$qty=$_POST['qty'];
		$price=$_POST['price'];
		
	    $update_query="update bill set 
		username='".$unm."',
		mobile_no='".$mno."',
		pro_name='".$pronm."',
		cat_name='".$catnm."',
		quantity='".$qty."',
		pro_price='".$price."'
		where id='".$uid."'";
		
		$updatedata=mysqli_query($db,$update_query);
		if($updatedata=1){
			header("location:bill_list.php");
		}
	}
	include("footer.php");
?>





















