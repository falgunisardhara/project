<?php
	include("header.php");
	include("connection.php");
	$list_query="select *from bill";
	$data_query=mysqli_query($db,$list_query);
?>

<html>
<body>
<h2 align="center">BILL DETAILS</h2>
<table border="2">
	<tr>
		<th>id</th>
		<th>user name</th>
		<th>mobile no</th>
		<th>pro_name</th>
		<th>cat_name</th>
		<th>quantity</th>
		<th>price</th>
		<th>action</th>
	</tr>
<?php
$path="images/";
while($list_data=mysqli_fetch_array($data_query)){?>
	
	<tr>
		<td><?php echo $list_data['0'];?></td>
		<td><?php echo $list_data['1'];?></td>
		<td><?php echo $list_data['2'];?></td>
		<td><?php echo $list_data['3'];?></td>
		<td><?php echo $list_data['4'];?></td>
		<td><?php echo $list_data['5'];?></td>
		<td><?php echo $list_data['6'];?></td>
		
		<td><a href="bill_delete.php?delete_id=<?php echo $list_data['id'];?>">DELETE</a></td>
		<td><a href="bill_update.php?update_id=<?php echo $list_data['id'];?>">UPDATE</a></td>
		
	</tr>
<?php } ?>
</table>
</body>
</html>
<?php
include("footer.php");?>