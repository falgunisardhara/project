<?php
include("header.php");
include("connection.php");
$uid=$_GET['update_id'];
$uquery="select *from product where id=".$uid;
$up_query=mysqli_query($db,$uquery);
$updata=mysqli_fetch_array($up_query);
?>

<html>
<body>

<h2 align="center">UPDATE PRODUCT DETAILS</h2>

<form method="post" enctype="multipart/form-data">
<table>
<tr>
<td align="center">PRODUCT NAME</td>
<td><input type="text" name="nm" value="<?php echo $updata['pro_name'];?>"/>
</td>
</tr>

</tr>
<tr>
<td align="center">PRODUCT COMPANY</td>
<td><input type="text" name="company" value="<?php echo $updata['pro_company'];?>" />
</td>
</tr>

<tr>
<td align="center">PRODUCT CATEGORY</td>
<td><input type="text" name="procat" value="<?php echo $updata['pro_category'];?>"/>
</td>
</tr>

<tr>
<td align="center">PRODUCT IMAGE</td>
<td><input type="file" name="img1" value="<?php echo $updata['pro_image'];?>"/>

</td>
<td><img src="images/ <?php echo $updata['4'];?>" height="100" width="100"/>
<input type="hidden" name="imgd" value="<?php echo $updata['4'];?>"/>
</td>
</tr>

<tr>
<td align="center">PRODUCT PRICE</td>
<td><input type="text" name="price" value="<?php echo $updata['pro_price'];?>" />
</td>
</tr>

<tr>
<td align="center">STOCK</td>
<td><input type="text" name="stock" value="<?php echo $updata['stock'];?>"/>
</td>
</tr>

<tr>
<td align="right"><input type="submit" name="update" value="Update"/>
</td>
</tr>

</table>
</body>
</html>

<?php
if(isset($_REQUEST['update']))
	{
		$nm=$_POST['nm'];
		$company=$_POST['company'];
		$procat=$_POST['procat'];
		if($_FILES['img1']['name']!=''){
			$imgg=$_FILES['img1']['name'];
			$dir="images/";
			$tot=$dir.basename($imgg);
			move_uploaded_file($_FILES['img1']['tmp_name'],$tot);
		}else{
			$imgg=$_POST['imgd'];
		}
		$price=$_POST['price'];
		$stock=$_POST['stock'];
		
	    $update_query="update product set 
		pro_name='".$nm."',
		pro_company='".$company."',
		pro_category='".$procat."',
		pro_image='".$imgg."',
		pro_price='".$price."',
		stock='".$stock."'
		where id='".$uid."'";
		
		$updatedata=mysqli_query($db,$update_query);
		if($updatedata=1){
			header("location:pro_list.php");
		}
	}
	include("footer.php");
?>





















