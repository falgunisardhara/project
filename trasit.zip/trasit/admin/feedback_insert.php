<?php
include("header.php");
?>
<html>
<body>
<h2 align="center">FEEDBACK</h2>

<form method="post" enctype="multipart/form-data">
<table>
<tr>
<td align="center">USER NAME</td>
<td><input type="text" name="unm" />
</td>

</tr>
<tr>
<td align="center">EMAIL</td>
<td><input type="text" name="email" />
</td>
</tr>

<tr>
<td align="center">MOBILE NO</td>
<td><input type="text" name="mno"/>
</td>
</tr>

<tr>
<td align="center">MESSAGE</td>
<td><textarea name="msg" rows="2" cols="30"/></textarea>
</td>
</tr>

<tr>
<td align="right"><input type="submit" name="submit" /><input type="reset" name="clear"/>
</td>
</tr>
</table>
</form>
</body>
</html>

<?php
	include("connection.php");
	if(isset($_REQUEST['submit']))
	{
		$unm=$_POST['unm'];
		$email=$_POST['email'];		
		$mno=$_POST['mno'];
		$msg=$_POST['msg'];
		
	    $iquery="insert into feedback(id,username,email,mobile_no,message)values(NULL,'".$unm."','".$email."','".$mno."','".$msg."')";
		$p1=mysqli_query($db,$iquery);
		
		if($p1=1)
		{
			header("location:feedback_list.php?msg1=inserted");
		}
		if($p1=0)
		{
			echo"not inserted";
		}
	}
	include("footer.php");
?>


