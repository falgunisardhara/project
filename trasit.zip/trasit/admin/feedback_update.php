<?php
include("header.php");
include("connection.php");
$uid=$_GET['update_id'];
$uquery="select *from feedback where id=".$uid;
$up_query=mysqli_query($db,$uquery);
$updata=mysqli_fetch_array($up_query);
?>

<html>
<body>

<h2 align="center">UPDATE FEEDBACK DETAILS</h2>

<form method="post" enctype="multipart/form-data">
<table>
<tr>
<td align="center">USER NAME</td>
<td><input type="text" name="unm" value="<?php echo $updata['username'];?>"/>
</td>
</tr>

</tr>
<tr>
<td align="center">EMAIL</td>
<td><input type="text" name="email" value="<?php echo $updata['email'];?>" />
</td>
</tr>

<tr>
<td align="center">MOBILE NO</td>
<td><input type="text" name="mno" value="<?php echo $updata['mobile_no'];?>"/>
</td>
</tr>

<tr>
<td align="center">MESSAGE</td>
<td><textarea name="msg" rows="2" cols="30" value="<?php echo $updata['message'];?>" /></textarea>
</td>
</tr>

<tr>
<td align="right"><input type="submit" name="update" value="Update"/>
</td>
</tr>

</table>
</body>
</html>

<?php
if(isset($_REQUEST['update']))
	{
		$unm=$_POST['unm'];
		$email=$_POST['email'];
		$mno=$_POST['mno'];
		$msg=$_POST['msg'];
		
	    $update_query="update feedback set 
		username='".$unm."',
		email='".$email."',
		mobile_no='".$mno."',
		message='".$msg."'
		where id='".$uid."'";
		
		$updatedata=mysqli_query($db,$update_query);
		if($updatedata=1){
			header("location:feedback_list.php");
		}
	}
	include("footer.php");
?>





















