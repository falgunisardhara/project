
<?php
include("header.php");
?>
<html>
<body>
<h2 align="center">PRODUCT</h2>

<form method="post" enctype="multipart/form-data">
<table>
<tr>
<td align="center">PRODUCT NAME</td>
<td><input type="text" name="nm" />
</td>
</tr>

<tr>
<td align="center">PRODUCT COMPANY</td>
<td><input type="text" name="company" />
</td>
</tr>

<tr>
<td align="center">PRODUCT CATEGORY</td>
<td><input type="text" name="procat" />
</td>
</tr>

<tr>
<td align="center">PRODUCT IMAGE</td>
<td><input type="file" name="img"/>
</td>
</tr>

<tr>
<td align="center">PRODUCT PRICE</td>
<td><input type="text" name="price" />
</td>
</tr>
<tr>
<td align="center">STOCK</td>
<td><input type="text" name="stock" />
</td>
</tr>

<tr>
<td align="right"><input type="submit" name="submit" /><input type="reset" name="clear"/>
</td>
</tr>
</table>
</form>
</body>
</html>

<?php
	include("connection.php");
	if(isset($_REQUEST['submit']))
	{
		$nm=$_POST['nm'];
		$company=$_POST['company'];
		$procat=$_POST['procat'];
		$img=$_FILES['img']['name'];
		$target_dir="images/";
		$imgs=$target_dir.basename($img);
		move_uploaded_file($_FILES['img']['tmp_name'],$imgs);
		$price=$_POST['price'];
		$stock=$_POST['stock'];
	
	    $iquery="insert into product(id,pro_name,pro_company,pro_category,pro_image,pro_price,stock)
		values(NULL,'".$nm."','".$company."','".$procat."','".$img."','".$price."','".$stock."')";
		
		$p1=mysqli_query($db,$iquery);
		
		if($p1=1)
		{
			header("location:pro_list.php?msg1=inserted");
		}
		if($p1=0)
		{
			echo"not inserted";
		}
	}
	include("footer.php");
?>


