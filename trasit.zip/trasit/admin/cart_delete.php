<?php
	include("header.php");
	include("connection.php");
	$id=$_GET['delete_id'];
	
	$delete_query="delete from add_to_cart where id=".$id;
	$del_id1=mysqli_query($db,$delete_query);
	
	if($delete_id1=1)
	{
		header("location:cart_list.php");
	}
	include("footer.php");
?>