<?php
include("header.php");
include("connection.php");
$uid=$_GET['update_id'];
$uquery="select *from category_data where id=".$uid;
$up_query=mysqli_query($db,$uquery);
$updata=mysqli_fetch_array($up_query);
?>

<html>
<body>

<h2 align="center">UPDATE CATEGORY DETAILS</h2>

<form method="post" enctype="multipart/form-data">
<table>

<tr>
<td align="center">CATEGORY IMAGE</td>
<td><input type="file" name="img1" value="<?php echo $updata['cat_image'];?>"/>
</td>
<td><img src="images/<?php echo $updata['1'];?>" height="100" width="100"/>
<input type="hidden" name="imgd" value="<?php echo $updata['1'];?>"/>
</td>
</tr>

<tr>
<td align="center">CATEGORY NAME</td>
<td><input type="text" name="nm" value="<?php echo $updata['cat_name'];?>" />
</td>
</tr>

<tr>
<td align="right"><input type="submit" name="update" value="Update"/>
</td>
</tr>

</table>
</body>
</html>

<?php
if(isset($_REQUEST['update']))
	{
		$nm=$_POST['nm'];
		if($_FILES['img1']['name']!=''){
			$imgg=$_FILES['img1']['name'];
			$dir="images/";
			$tot=$dir.basename($imgg);
			move_uploaded_file($_FILES['img1']['tmp_name'],$tot);
		}else{
			$imgg=$_POST['imgd'];
		}
		
	    $update_query="update category_data set 
		cat_image='".$imgg."',
		cat_name='".$nm."'
		where id='".$uid."'";
		
		$updatedata=mysqli_query($db,$update_query);
		if($updatedata=1){
			header("location:cat_list.php");
		}
	}
	include("footer.php");
?>





















