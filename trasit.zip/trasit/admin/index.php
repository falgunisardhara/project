<!DOCTYPE html>
<!--
	Transit by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Transit by TEMPLATED</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
	</head>
	<body class="landing">
	</body>
	</html>

<?php
	include("header.php");
?>

<html>
<head>
	<h2><strong><center><u>HOME</u></center></strong></h2>
	<h3><p> Watches are the best gifts for birthdays,anniversery and also for a weddings.</p></h3>
	<h3><p> This is the <u>TIC TOC!</u> wrist watch shopping site.</p></h3>
	<h3><p>In this site, we proving four  watch companies which has a different categories. </p></h3>
	<img src="images/omega.png" height="250"><img src="images/omega black dial silver couple watch.jpg" height="250">
	<h3><p>We provies this company name omega. The most expensive watch company which is the best for the couples. </p></h3>
	
	
	<img src="images/Rolex.png" height="250"><img src="images/rolex platinum president silver women watch.jpg" height="250">
	<h3><p>Rolex is a another  famous company for it's watches.Their watches is more popular compare to other company's watches. </p></h3>
	
	<img src="images/titan.png" height="250"><img src="images/titan pink flower kids watch.jpeg" height="250">
	<h3><p>The TITAN satnd for Tata Industries TAmil Nadu.Watch project began with the signing of a joint venture of tata industries with the Tamil Nadu Industrial Devlopment Corporation(TIDCO) in june 1984. </p></h3>
			
			<h3><p>Titan watches LTd. commenced production in the year 1986  and hit the market in march 1987 with its brand 'TITAN'. In 1993 the name of the company was changed with effect from 21 september from titan watches, LTD. to titan industries LTd.</p></h3>


	<img src="images/timex.png" height="250"><img src="images/titan black dial men gold & silver watch.jpg" height="250">
		<h3><p> Today the timex is well known company just like Omega,Rolex and so on.
		</p></h3>
</head>
</html>

<?php
	include("footer.php");
?>