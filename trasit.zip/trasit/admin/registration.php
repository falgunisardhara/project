<?php
include("header.php");
?>
<html>
<body><title>Registration</title>
<h2 align="center"> ADMIN REGISTRATION FORM</h2>

<form method="post" enctype="multipart/form-data"/>
<table>
<tr>
<td align="center">Username</td>
<td><input type="text" name="unm"required/>
</td>
</tr>

<tr>
<td align="center">Email</td>
<td><input type="text" name="email" pattern=".+@gmail.com" size="30"required />
</td>
</tr>

<tr>
<td align="center">Password</td>
<td><input type="password" name="pwd" minlength="8"required />
</td>
</tr>

<tr>
<td align="center">Confirm password</td>
<td><input type="password" name="conpwd" minlength="8"required />
</td>
</tr>

<tr>
<td align="center">Mobile no</td>
<td><input type="text" name="mno"required />
</td>
</tr>

<tr>
<td align="right"><input type="submit" name="submit" /><input type="reset" name="clear"/>
</td>
</tr>
</table>
</form>
</body>
</html>

<?php
	include("connection.php");
	
	if(isset($_REQUEST['submit']))
	{
		$unm=$_POST['unm'];
		$fnm=$_POST['fnm'];
		$lnm=$_POST['lnm'];
		$email=$_POST['email'];
		$pwd=$_POST['pwd'];
		$conpwd=$_POST['conpwd'];
		$mno=$_POST['mno'];
		
		$iquery="insert into registration(id,username,email,password,confirm_password,mobile_no)
		values(NULL,'".$unm."','".$email."','".$pwd."','".$conpwd."','".$mno."')";
		$p1=mysqli_query($db,$iquery);
		
		if($_POST['conpwd']!==$_POST['pwd'])
		{
			echo "invalid password";
		}
		else
		{
			if($p1=1)
			{
				header("location:rlist.php?msg1=inserted");
			}
		}
		if($p1=0)
		{
			echo"not inserted";
		}
	}
	include("footer.php");
?>
