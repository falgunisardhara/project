<?php
	include("header.php");
	include("connection.php");
	$list_query="select *from feedback";
	$data_query=mysqli_query($db,$list_query);
?>

<html>
<body>
<h2 align="center">FEEDBACK DETAILS</h2>
<table border="2">
	<tr>
		<th>id</th>
		<th>unm</th>
		<th>email</th>
		<th>mno</th>
		<th>msg</th>
		<th>action</th>
	</tr>
<?php
$path="images/";
while($list_data=mysqli_fetch_array($data_query)){?>
	
	<tr>
		<td><?php echo $list_data['0'];?></td>
		<td><?php echo $list_data['1'];?></td>
		<td><?php echo $list_data['2'];?></td>
		<td><?php echo $list_data['3'];?></td>
		<td><?php echo $list_data['4'];?></td>
		
		
		<td><a href="feedback_delete.php?delete_id=<?php echo $list_data['id'];?>">DELETE</a></td>
		<td><a href="feedback_update.php?update_id=<?php echo $list_data['id'];?>">UPDATE</a></td>
		
	</tr>
<?php } ?>
</table>
</body>
</html>
<?php
include("footer.php");?>